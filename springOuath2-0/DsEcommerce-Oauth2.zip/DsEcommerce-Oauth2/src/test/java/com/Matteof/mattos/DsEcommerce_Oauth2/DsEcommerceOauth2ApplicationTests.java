package com.Matteof.mattos.DsEcommerce_Oauth2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DsEcommerceOauth2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
